from django.apps import AppConfig


class HousePriceModelConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "House_Price_model"
